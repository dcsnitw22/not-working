package grpcNgapNas

import (
	"context"
	"errors"
	"log"
	"nas"
	"nasMain/grpcNgapNas/pb"
	grpcSMclient "nasMain/grpcSMclient/client"

	"net"
	"time"

	"google.golang.org/grpc"
	"google.golang.org/protobuf/types/known/anypb"
)

// Capacity of GRPC Channel
const (
	GrpcChannelCapacity = 100
)

// Structure for Channel that sends data to CSP
type GrpcNgapNasChan struct {
	EPD         string
	MESSAGETYPE string
	FILE        []byte
}

// Structure for GRPC server
type ClassifierServer struct {
	pb.UnimplementedClassifierServer
	GrpcNgapChannel chan *GrpcNgapNasChan
	ServerIP        string
	ServerPort      string
	SMClientAddr    string
}

// Initialize server with config data
// Send to grpcChannel
func NewGrpcServer(cfg config.GrpcNasInfoConfig) *ClassifierServer {
	return &ClassifierServer{
		GrpcNgapChannel: make(chan *GrpcNgapNasChan, GrpcChannelCapacity),
		ServerIP:        cfg.ServerIP,
		ServerPort:      cfg.ServerPort,
		SMClientAddr:    cfg.SMClientAddr,
	}
}

// Gives the request type and message type of the binary file from UE
func (s *ClassifierServer) ClassifyFile(ctx context.Context, req *pb.FileRequest) (*pb.FileResponse, error) {
	//To send the error
	var errMsg string
	//Interface for decoded message
	var decodedMsg nas.NasDecodedMsg
	// // Create a temporary file to store the received content
	// tempFile, err := os.CreateTemp("", "received_file_")
	// if err != nil {
	// 	return nil, err
	// }
	// defer tempFile.Close()

	// // Write the received content to the temporary file
	// if _, err := tempFile.Write(req.File); err != nil {
	// 	return nil, err
	// }

	// // Seek to the beginning of the file
	// if _, err := tempFile.Seek(0, 0); err != nil {
	// 	return nil, err
	// }

	// Call the classification function
	epd, messageType, err := nas.Classify(req.File)
	if err != nil {
		return nil, err
	}

	//Set the error message, send data to channel and send response to NGAP
	if epd == "SESSION_MANAGEMENT_MESSAGES" {
		errMsg = "SESSION_MANAGEMENT_MESSAGES"

		s.GrpcNgapChannel <- &GrpcNgapNasChan{
			EPD:         epd,
			MESSAGETYPE: messageType,
			FILE:        req.File,
		}
		//Response to NGAP
		return &pb.FileResponse{
			DecodedNasMessage: nil,
			Error:             errMsg,
		}, nil
	}
	if epd == "MOBILITY_MANAGEMENT_MESSAGES" {
		decodedMsg, err = nas.ReRoute(epd, messageType, req.File)
		if err != nil {
			return nil, err
		}
		anyMsg, err := constructAnyMessage(decodedMsg)
		if err != nil {
			return nil, err
		}
		return &pb.FileResponse{
			DecodedNasMessage: anyMsg,
			Error:             "",
		}, nil
	}

	// Return error if epd does not match known types
	errMsg = "UNKNOWN_MESSAGE_TYPE"
	return &pb.FileResponse{
		DecodedNasMessage: nil,
		Error:             "",
	}, errors.New(errMsg)

}

// Run the server
func (s *ClassifierServer) RunNasNgapServer() {
	//Create the server address from the config file
	servAddr := s.ServerIP + ":" + s.ServerPort
	//Start the server
	lis, err := net.Listen("tcp", servAddr)
	if err != nil {
		log.Fatalf("failed to listen: %v", err)
	}
	//Initiate the server
	server := grpc.NewServer()
	//Register the server
	pb.RegisterClassifierServer(server, s)
	log.Print("server listening at %v", lis.Addr())

	// Start a goroutine to watch the channel
	go s.watchChannelAndSendSMData()

	if err := server.Serve(lis); err != nil {
		log.Fatalf("failed to serve: %v", err)
	}
}

// Runs as soon as channel sends data
func (s *ClassifierServer) watchChannelAndSendSMData() {
	for data := range s.GrpcNgapChannel {
		// Start a new goroutine to handle sending data to SMClient
		go func(data *GrpcNgapNasChan) {
			smClient, err := grpcSMclient.NewSMClient(s.SMClientAddr)
			if err != nil {
				log.Printf("Failed to create SMClient: %v", err)
			}
			defer smClient.Close()

			ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
			defer cancel()

			if err := smClient.SendSMData(ctx, data.EPD, data.MESSAGETYPE, data.FILE); err != nil {
				log.Printf("Failed to send SM data: %v", err)
			}
		}(data)
	}

	// pdu := <-s.GrpcNgapChannel
	// smClient, err := grpcSMclient.NewSMClient(s.SMClientAddr)
	// if err != nil {
	// 	log.Printf("Failed to create SMClient: %v", err)
	// }
	// defer smClient.Close()

	// ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	// defer cancel()

	// if err := smClient.SendSMData(ctx, pdu.EPD, pdu.MESSAGETYPE, pdu.FILE); err != nil {
	// 	log.Printf("Failed to send SM data: %v", err)
	// }

}

func constructAnyMessage(decodedMsg interface{}) (*anypb.Any, error) {
	var anyMsg *anypb.Any
	var err error

	switch msg := decodedMsg.(type) {
	case nas.ULNasModel:
		responseData := &pb.UlNas{
			Epd:            msg.ExtendedProtocolDiscriminator,
			Sht:            msg.SecurityHeaderType,
			MessageType:    msg.MessageType,
			PayloadConType: msg.PayLoadContainerType,
		}
		anyMsg, err = anypb.New(responseData)
	case nas.RegistrationRequestModel:
		responseData := &pb.RegistrationRequest{
			Epd:              msg.ExtendedProtocolDiscriminator,
			Sht:              msg.SecurityHeaderType,
			MessageType:      msg.MessageType,
			RegistrationType: msg.RegistrationType,
			ForValue:         msg.FORValue,
			NASKSI:           msg.NASKSI,
			NASTSC:           msg.NASTSC,
			MobileIdentity:   msg.MobileIdentity,
		}
		anyMsg, err = anypb.New(responseData)
	}
	return anyMsg, err

}
